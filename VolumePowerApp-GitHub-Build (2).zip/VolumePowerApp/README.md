# Volume Power

A standalone Android app for the Vivo V9 / Android 10 use case:

- Volume Up + screen ON -> lock screen
- Volume Up + screen OFF -> wake screen
- Volume Down -> completely untouched
- No root
- No screen capture
- No OCR
- No AI

## Setup

1. Install the APK.
2. Open **Volume Power**.
3. Tap **Open Accessibility Settings**.
4. Enable **Volume Power**.
5. Return to the app.
6. Turn on **Enable Volume Up Power**.
7. Press Volume Up to test.

If Vivo/Funtouch OS stops the service, allow the app to run in the background and disable battery optimization for it.

## Important limitation

This cannot boot a phone that is completely powered off. Android must already be running and the Accessibility Service must be active.

## Build

Open the project in Android Studio and generate a debug APK, or run:

./gradlew assembleDebug

The APK will normally be:

app/build/outputs/apk/debug/app-debug.apk

## Design

The service requests Android Accessibility key-event filtering and handles only KEYCODE_VOLUME_UP. It returns false for every other key, so Volume Down is not handled by this app.

The screen-wake path uses a short SCREEN_BRIGHT_WAKE_LOCK + ACQUIRE_CAUSES_WAKEUP. ACQUIRE_CAUSES_WAKEUP is deprecated on newer Android versions but remains available on the user's Android 10 target. The wake lock is time-limited to avoid being held indefinitely.


## Build an APK on GitHub (phone-only)

1. Create a new **public or private repository** on GitHub named `VolumePowerApp`.
2. In the repository, use **Add file → Upload files** and upload the *contents* of this folder, including the hidden `.github` folder if GitHub's upload interface permits it.
3. Commit the files to the `main` branch.
4. Open the repository's **Actions** tab and choose **Build Volume Power APK**.
5. If the workflow has not run automatically, tap **Run workflow**.
6. Open the completed run and scroll to **Artifacts**. Download `VolumePower-debug-apk`, then extract the downloaded ZIP to get `app-debug.apk`.
7. Install the APK on your phone. Android may ask you to allow installation from your browser/file manager.

The workflow builds a debug APK; it is not a Play Store release. The app needs its Accessibility Service enabled and its in-app switch turned on. Volume Up is intercepted by the service; other keys should be passed through. Waking a sleeping screen can vary by Vivo/Android firmware, so test it on your phone. It cannot power on a fully shut-down phone.
