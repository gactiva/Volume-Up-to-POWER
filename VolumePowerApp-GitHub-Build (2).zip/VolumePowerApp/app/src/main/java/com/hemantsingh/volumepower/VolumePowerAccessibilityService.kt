package com.hemantsingh.volumepower

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.os.PowerManager
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

class VolumePowerAccessibilityService : AccessibilityService() {

    private val prefs by lazy {
        getSharedPreferences("settings", Context.MODE_PRIVATE)
    }

    override fun onServiceConnected() {
        super.onServiceConnected()

        serviceInfo = serviceInfo.apply {
            flags = flags or
                android.accessibilityservice.AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
        }
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (!prefs.getBoolean("enabled", false)) return false

        // ONLY Volume Up. Volume Down is never handled.
        if (event.keyCode != KeyEvent.KEYCODE_VOLUME_UP) return false

        // Consume the whole Volume Up press so it does not also change volume.
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager

            if (powerManager.isInteractive) {
                // GLOBAL_ACTION_LOCK_SCREEN is available from API 28,
                // so it is available on the user's Android 10 device.
                performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
            } else {
                wakeScreen()
            }
        }

        return true
    }

    private fun wakeScreen() {
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager

        @Suppress("DEPRECATION")
        val wakeLock = powerManager.newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or
                PowerManager.ACQUIRE_CAUSES_WAKEUP or
                PowerManager.ON_AFTER_RELEASE,
            "VolumePower::Wake"
        )

        @Suppress("DEPRECATION")
        wakeLock.acquire(1500L)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // No screen content is read by this service.
    }

    override fun onInterrupt() {
        // Nothing to interrupt.
    }
}
